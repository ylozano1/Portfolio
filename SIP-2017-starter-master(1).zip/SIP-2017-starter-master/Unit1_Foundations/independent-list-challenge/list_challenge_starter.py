
from random import *


#Create the list of words you want to choose from.
word_list = []

#Generates a random integer.
x = randint(0, len(word_list)-1)
