# Unit 1: Foundations

1. [Shapes 2](shapes2)
1. [Text Adventure](text-adventure)
1. [Core4 Portfolio Page](core4-portfolio-page)
1. [Independent List Challenge](independent-list-challenge)
1. [Paired Programming List Challenge](paired-list-challenge)
1. [Obamicon](obamicon)