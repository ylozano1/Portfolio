# SIP 2017 Starter Code

This repo contains the starter code for student projects for the 2017 Girls Who Code Summer Immersion Program.