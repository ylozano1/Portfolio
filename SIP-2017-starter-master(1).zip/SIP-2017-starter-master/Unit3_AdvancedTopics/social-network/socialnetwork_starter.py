class User:
    # Define the fields and methods for your object here.


class Network:
    # Define the fields and methods for your object here.


def main():
    # Define the program flow for your user interface here.


# Runs your program.
if __name__ == '__main__':
    main():
