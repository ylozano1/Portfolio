# Social Network

To run on Mac:
`$ python3 social_network.py`

To run on Windows:
`$ python social_network.py`