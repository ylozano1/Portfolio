# Binary Search

To run on Mac:
`$ python3 binarysearch.py`

To run on Windows:
`$ python binarysearch.py`