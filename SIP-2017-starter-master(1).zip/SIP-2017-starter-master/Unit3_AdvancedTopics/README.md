# Unit 3: Advanced Topics

1. [Binary Search](binary-search)
2. [Social Network](social-network)