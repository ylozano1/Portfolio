# Mystery Text

To run:

1. Open in Arduino.
1. Plug in robot using USB.
1. Verify code.
1. Upload program to robot.