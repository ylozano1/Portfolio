# Unit 2: Applications

1. [Mystery Text](mystery-text)
1. [Dictionary Attack](dictionary-attack)