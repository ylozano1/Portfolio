# Dictionary Attack

The dictionary text file used is from [github.com/dwyl](https://github.com/dwyl/english-words/blob/master/words.txt).

To run: Open `dictionary-attack.html` in your favorite browser.
